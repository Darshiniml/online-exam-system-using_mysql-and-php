# DBMS-MINI-Project
 DBMS project on topic Online Examination System

Technology Used:

Front-End: HTML,CSS,JavaScript

Back-End: PHP,MySql

Software Used:XAMPP

How to run this project locally

    clone this repo to www folder in WAMP software
    import the SQL file WAMP.
    replace database name in sql.php file with your database credentials.
    open localhost in browser. you see the home page


ONLINE EXAMINATION SYSTEM is a web-based examination system where examinations are given online. either through the internet or intranet using computer system. The main goal of this online examination system is to effectively evaluate the student thoroughly through a totally automated system that not only reduce the required time but also obtain fast and accurate results.

ONLINE EXAMINATION SYSTEM is an online test simulator is to take online examination, test in an efficient manner and no time wasting for manually checking of the test paper. The main objective of this web based online examination system is to efficiently evaluate the student thoroughly through a fully automated system that not only saves lot of time but also gives fast and accurate results. For students they give papers according to their convenience from any location by using internet and time and there is no need of using extra thing like paper, pen etc.

Functional Specification:

Registering new Student
Getting the student and staff info and storing it to databases
Getting the type and number of question paper 
Generating result after the exam.

<img src="https://camo.githubusercontent.com/aa7164b3deb35cccd8e40161c8f520b459df4e4a/68747470733a2f2f696d6775722e636f6d2f6358536772584f2e706e67">

<img src="https://camo.githubusercontent.com/f61913e9426360233edc15d6a7e3674b20c80089/68747470733a2f2f696d6775722e636f6d2f4345565061456d2e706e67">

<img src="https://camo.githubusercontent.com/eabe1d97a08bbb8e7b6aa20f07fea37c19bfa5f1/68747470733a2f2f696d6775722e636f6d2f6b3875434b6d462e706e67">

<img src="https://camo.githubusercontent.com/64ee2cf3a29088c0e853265eebaf960247471c07/68747470733a2f2f696d6775722e636f6d2f656c585444554c2e706e67">

<img src="https://camo.githubusercontent.com/bbf32a2f6c31be2d2268970337563020e53f5e79/68747470733a2f2f696d6775722e636f6d2f626f47335544352e706e67">

<img src="https://camo.githubusercontent.com/77fc1ffd87d0bba39a44666e4d45d0eb41d40bdd/68747470733a2f2f696d6775722e636f6d2f6b33654c5462782e706e67">

<img src="https://camo.githubusercontent.com/2473e3c0447f697909692550e6648a6cb143143f/68747470733a2f2f696d6775722e636f6d2f7271617a5a666c2e706e67">

<img src="https://camo.githubusercontent.com/c59546452df181f52f6ce767bc1555f4eb91fd4b/68747470733a2f2f696d6775722e636f6d2f676473436d6f592e706e67">

<img src="https://camo.githubusercontent.com/3265cb3c967afc5cb380f19ef540c804bc23dd44/68747470733a2f2f696d6775722e636f6d2f745265575263772e706e67">




